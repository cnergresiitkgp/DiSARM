<?php
  echo "hi.............";
  if(isset($_POST['sub'])) {
		$firstname = $_POST['firstname'];
		$lastname = $_POST['lastname'];
		$donated_by = $firstname.' '.$lastname;
		$address = $_POST['address'];
		$land = $_POST['landmark'];
		//$address_land = $address.' '.$land;
		$phone = $_POST['phone'];
		$gender = $_POST['state'];
		$district = $_POST['district'];
		$area = $_POST['block'];
		$municipality = $_POST['municipalaty'];
		$block_area = $_POST['village'];
		
		
		//$check_donate = $_POST['resource_donate'];
		//$check_service = $_POST['resource_sevice'];
		include("connect.inc.php");	
  	
		$selected_radio = $_POST['gender'];
  
			if ($selected_radio == 'resour') {
  
				  echo "hi @@@@@@@@@@@@";
				  $resource_name = $_POST['resource_1'];
				  $unit = $_POST['unit_1'];
				  $quantity = $_POST['quan'];
				  //$exact_quantity = $quantity.' '.$unit;
				  
				  $sql = "INSERT INTO `donate_master`(`donated_by`, `resource_name`, `resource_unit`, `resource_amount`, `address`, `landmark`, `state`, `district`, `block`, `panchayat_municipality`, `village_area`) 
				  VALUES ('$donated_by','$resource_name','$unit','$quantity','$address','$land','$gender','$district','$area','$municipality','$block_area')";
				  echo $sql;
				  $result=mysql_query($sql,$connect);
					  if($result){	
							header("location:donate.php?flag=true");
					  }
					  else {	
							header("location:donate.php?flag=false");
						} 
				  }
			  else if ($selected_radio == 'service') {
			  
			  echo "%%%%%%%%%%%";
			  $subject = $_POST['subject'];
				$message = $_POST['message'];
				$importance = $subject.' '.$message;
			  $sql_service = "INSERT INTO `donate_master`(`donated_by`, `resource_others`, `address`, `landmark`, `state`, `district`, `block`, `panchayat_municipality`, `village_area`) 
			  VALUES ('$donated_by','$importance','$address','$land','$gender','$district','$area','$municipality','$block_area')";
			  echo $sql_service;
			  $result_service = mysql_query($sql_service,$connect);
				  if($result_service){	
						header("location:helpme.php?flag=true");
				  }
				  else {	
						header("location:helpme.php?flag=false");
					} 
			  }
  }
  	
  //echo '<pre>', print_r($_POST), '</pre>';die;
  
  ?>
