<?php
include("connect.inc.php");
Session_start();	
echo "hi!!!!!!!";
if(isset($_POST['sub'])) {
	echo "hellooooooo!!!!!!!";
$volunteer_name = $_POST['vol_name'];	
echo $volunteer_name;
$contact_number = $_POST['con_number'];
echo $contact_number;
$district = $_POST['district'];
$state = $_POST['state'];
$block = $_POST['block'];
$panchayat = $_POST['panchayat'];
$village = $_POST['village'];

$sql = "SELECT `state` FROM `state` WHERE `id`= $state";
$sql1 = "SELECT `district` FROM `district` WHERE `id`= $district";
$sql2 = "SELECT `block` FROM `block` WHERE `id`= $block";
$sql3 = "SELECT `panchayat` FROM `panchayat_municipalaty` WHERE `id`= $panchayat";
$sql4 = "SELECT `village` FROM `village` WHERE `id`= $village";
$output = mysql_query($sql,$connect);

$output1 = mysql_query($sql1,$connect);
$output2 = mysql_query($sql2,$connect);
$output3 = mysql_query($sql3,$connect);
$output4 = mysql_query($sql4,$connect);

$result= mysql_fetch_assoc($output);
$result1= mysql_fetch_assoc($output1);
$result2= mysql_fetch_assoc($output2);
$result3= mysql_fetch_assoc($output3);
$result4= mysql_fetch_assoc($output4);

$track_state = $result["state"];
$track_district = $result1["district"];
$track_block = $result2["block"];
$track_panchayat = $result3["panchayat"];
$track_village = $result4["village"];
$address = $track_state.' '.$track_district.' '.$track_block.' '.$track_panchayat.' '.$track_village;
echo "<br/>address =".$address;

$skill = $_POST['skills']; 
$expart = $_POST['train'];
$affiliation = $_POST['affiliation'];
$designation = $_POST['designation'];

echo "<br/>skill =".$skill;
echo "<br/>affiliation =".$affiliation;
echo "<br/> designation =".$designation;
echo "<br/> expart =".$expart;
$block = $_POST['block'];
$panchayat = $_POST['panchayat'];
$village = $_POST['village'];
$sql5 = "SELECT `block` FROM `block` WHERE `id`= $block";
$sql6 = "SELECT `panchayat` FROM `panchayat_municipalaty` WHERE `id`= $panchayat";
$sql7 = "SELECT `village` FROM `village` WHERE `id`= $village";
$output5 = mysql_query($sql5,$connect);
$output6 = mysql_query($sql6,$connect);
$output7 = mysql_query($sql7,$connect);
$result5= mysql_fetch_assoc($output5);
$result6= mysql_fetch_assoc($output6);
$result7= mysql_fetch_assoc($output7);

$track_block1 = $result5["block"];
$track_panchayat1 = $result6["panchayat"];
$track_village1 = $result7["village"];
$work_address = $track_block1.' '.$track_panchayat1.' '.$track_village1;
echo "<br/>volunteer working address =".$work_address;
$name = $_SESSION['firstname'];
echo "$$$$".$name;
$sql_affiliation = "SELECT `affiliation` FROM `register_master` WHERE `firstname`= '$name'";
echo $sql_affiliation;
$output_affiliation = mysql_query($sql_affiliation,$connect);

$result_affiliation= mysql_fetch_assoc($output_affiliation);
$affiliation = $result_affiliation['affiliation']; 
echo $affiliation;
//echo '<pre>', print_r($_POST), '</pre>';die;

$sql = "INSERT INTO `volunteer_master`(`volunteer_name`, `state`, `district`, `block`, `panchayat`, `village`, `contact_number`, `Affiliation`, `Designation`, `work_block`, `work_panchayat`, `work_village`, `skills`, `expertise`) 
VALUES ('$volunteer_name','$track_state','$track_district','$track_block','$track_panchayat','$track_village','$contact_number','$affiliation','$designation','$track_block1','$track_panchayat1','$track_village1','$skill','$expart')";

/*$sql = "INSERT INTO `volunteer_master`(`volunteer_name`, `volunteer_address`, `contact_number`, `Affiliation`, `Designation`, `work_location`, `skills`, `expertise`) 
VALUES ('$volunteer_name','$address','$contact_number','$affiliation','$designation','$work_address','$skill','$expart')";*/
echo $sql;
$result_data=mysql_query($sql,$connect);
echo $result_data;
							if($result_data){	
							
								header("location:manage_volunteers.php?flag=true");
									
									
							}
							else {	
									header("location:manage_volunteers.php?flag=false");
								}
}
//echo '<pre>', print_r($_POST), '</pre>';die;
?>
