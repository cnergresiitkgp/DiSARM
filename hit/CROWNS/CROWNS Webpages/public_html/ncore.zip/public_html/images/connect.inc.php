<?php
$error='Could not connect';
$host = 'localhost';
$user = 'root';
$pass = NULL;
$db = 'a5363301_crowns';
global $id;

// Create connection
$conn = new mysqli($host, $user, $pass, $db);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
$conn->query("set character_set_results='utf8'");
?>
