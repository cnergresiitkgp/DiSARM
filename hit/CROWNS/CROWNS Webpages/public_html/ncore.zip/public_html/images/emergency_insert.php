<?php

echo '<pre>', print_r($_POST), '</pre>';
if(isset($_POST['submit'])){

    $firstname = $_POST['firstname'];
	$lastname = $_POST['lastname'];
	$name = $firstname.' '.$lastname;	
	$phone = $_POST['phone'];
	$message = $_POST['message'];
	$state = $_POST['state'];
	$district = $_POST['district'];
	$block = $_POST['block'];
	$municipality = $_POST['pan_muni'];
	$village = $_POST['village'];
	$location = $_POST['location'];
	
	include("connect.inc.php");	
	
    $sql = "INSERT INTO `emergency_master`(`name`, `contact_no`, `prob_details`, `state`, `district`, `block`, `municipalaty`, `area`, `is_present`) 
	VALUES ('$name','$phone','$message','$state','$district','$block','$municipality','$village','$location')";
	
	echo '<pre>', $sql, '</pre>';
	
	$result=mysql_query($sql,$connect);
		if($result){	
				header("location:emergency.php?flag=true");
		}
		else {	
				header("location:emergency.php?flag=false");
			} 
}


?>
